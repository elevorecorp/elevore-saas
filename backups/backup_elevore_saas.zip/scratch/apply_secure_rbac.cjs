const postgres = require('postgres');
const fs = require('fs');
const path = require('path');

const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    const sqlPath = path.join(__dirname, '../supabase_secure_rbac.sql');
    console.log(`Reading SQL script from: ${sqlPath}`);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');

    console.log("Applying RLS and RBAC policies migrations to database...");
    
    // Execute the SQL file. We split by comments or run as a single query since postgres-js supports multi-query blocks.
    await sql.unsafe(sqlContent);

    console.log("✅ Security policies migrations applied successfully!");
  } catch (err) {
    console.error("❌ Failed to apply security migrations:", err);
  } finally {
    await sql.end();
  }
}

main();
