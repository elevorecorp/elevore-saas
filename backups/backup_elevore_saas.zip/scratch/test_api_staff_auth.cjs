const fs = require('fs');
const path = require('path');

// Manually parse .env file
const envPath = path.join(__dirname, '../.env');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2].trim();
      // Remove optional quotes
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value;
    }
  });
}

const handler = require('../api/staff-auth.js').default;

async function testLogin() {
  const req = {
    method: 'POST',
    query: { action: 'login' },
    body: {
      email: 'jei@gmail.com',
      passcode: '1111'
    },
    headers: {}
  };

  let statusCode = null;
  let responseData = null;

  const res = {
    setHeader(name, value) {},
    status(code) {
      statusCode = code;
      return this;
    },
    json(data) {
      responseData = data;
      return this;
    },
    end() {
      return this;
    }
  };

  console.log("Simulating Vercel Serverless Function Call for Login with loaded env...");
  await handler(req, res);

  console.log("Response Status:", statusCode);
  console.log("Response Data:", responseData);

  if (statusCode === 200 && responseData.success) {
    console.log("✅ SUCCESS: API authenticated the staff member successfully!");
  } else {
    console.log("❌ FAILED: API could not authenticate the staff member.");
  }
}

testLogin();
