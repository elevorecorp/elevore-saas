const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = "https://ceijlgurveaalvjmptns.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNlaWpsZ3VydmVhYWx2am1wdG5zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY4MTYwMzEsImV4cCI6MjA5MjM5MjAzMX0.XaPMpXxwMKRM09YN9kroF-gnISM2gBn29wi2R2UdOIc";

const sb = createClient(supabaseUrl, supabaseAnonKey);

async function main() {
  const pin = '1111';
  const email = 'jei@gmail.com';
  console.log(`Testing RPC login_staff_secure with PIN: ${pin}, Email: ${email}`);

  const { data, error } = await sb
    .rpc('login_staff_secure', {
      p_email: email,
      p_passcode: pin
    });

  if (error) {
    console.error("RPC Error:", error);
    return;
  }

  console.log("RPC returned:", data);
  if (data && data.length > 0) {
    console.log("✅ SUCCESS: Staff matched and retrieved securely without RLS blocking!");
  } else {
    console.log("❌ FAILED: No match found.");
  }
}

main();
