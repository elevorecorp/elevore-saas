const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    const result = await sql.begin(async tx => {
      return await tx`UPDATE public.staff_profiles SET wallet_balance = 9999.99 WHERE name = 'nonexistent'`;
    });
    console.log("Result object:", result);
    console.log("Count:", result.count);
    console.log("Length:", result.length);
  } catch (err) {
    console.error(err);
  } finally {
    await sql.end();
  }
}
main();
