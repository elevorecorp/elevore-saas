const postgres = require('postgres');
const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    console.log("=== POLICIES ON tenants ===");
    const policies = await sql`
      SELECT schemaname, tablename, policyname, roles, cmd, qual, with_check 
      FROM pg_policies 
      WHERE tablename = 'tenants'
    `;
    console.table(policies);
  } catch (err) {
    console.error("Error fetching policies:", err);
  } finally {
    await sql.end();
  }
}

main();
