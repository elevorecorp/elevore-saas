$path = 'c:\Users\Jose Mario\OneDrive\Escritorio\Nuevo proyecto Saas\src\App.jsx'
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# Map of corrupted sequences -> correct characters
$replacements = @(
  # Em dash
  @('\u00d4\u00c7\u00f6', '\u2014'),      # ÔÇö -> —
  # Right arrow  
  @('\u00d4\u00e5\u00c6', '\u2192'),      # ÔåÆ -> →
  # Bullet point
  @('\u00d4\u00c7\u00f3', '\u2022'),      # ÔÇó -> •
  # Left single quote
  @('\u00d4\u00c7\u00d4', '\u2018'),      # ÔÇÔ -> '
  # Right single quote / apostrophe
  @('\u00d4\u00c7\u00d6', '\u2019'),      # ÔÇÖ -> '
  # Left double quote
  @('\u00d4\u00c7\u00dc', '\u201c'),      # ÔÇÜ -> "
  # Right double quote
  @('\u00d4\u00c7\u00dd', '\u201d'),      # ÔÇÝ -> "
  # Ellipsis
  @('\u00d4\u00c7\u00a6', '\u2026'),      # ÔÇ¦ -> …
  # Copyright
  @('\u00c2\u00ae', '\u00a9'),            # ┬® -> ©
  # Check mark / tick
  @('\u00d4\u00a3\u00f4', '\u2713'),      # Ô£ô -> ✓
  # X mark
  @('\u00d4\u00a3\u00f2', '\u2717'),      # Ô£ò -> ✗
  # Star / black star
  @('\u00d4\u00bf\u00e0', '\u2605'),      # Ôÿà -> ★
  # White star
  @('\u00d4\u00a1\u00c9', '\u2b50'),      # Ô¡É -> ⭐
  # Envelope
  @('\u00d4\u00a3\u00eb', '\u2709'),      # Ô£ë -> ✉
  # Lightning / zap
  @('\u00d4\u00dc\u00ed', '\u26a1'),      # ÔÜí -> ⚡
  # Write/edit
  @('\u00d4\u00a3\u00ec', '\u270d'),      # Ô£ì -> ✍
  # 4-byte emoji sequences (encoded as ­ƒ sequences)
  @('\u00ad\u0192\u00ba\u2563', '\U0001f9f9'),  # 🧹
  @('\u00ad\u0192\u00f6\u00ba', '\U0001f527'),  # 🔧
  @('\u00ad\u0192\u00c6\u2590', '\U0001f4b0'),  # 💰
  @('\u00ad\u0192\u00f8\u00ed', '\U0001f3e1'),  # 🏡
  @('\u00ad\u0192\u00ba\u00bc', '\U0001f9fc'),  # 🧼
  @('\u00ad\u0192\u00d1\u00fb', '\U0001f916'),  # 🤖
  @('\u00ad\u0192\u00dc\u00c4', '\U0001f680'),  # 🚀
  @('\u00ad\u0192\u00d4\u00b2', '\U0001f4b2'),  # 💲
  @('\u00ad\u0192\u00c6\u00b3', '\U0001f4b3'),  # 💳
  @('\u00ad\u0192\u00c6\u00bc', '\U0001f4bc'),  # 💼
  @('\u00ad\u0192\u00c6\u00bc', '\U0001f4ac'),  # 💬
  @('\u00ad\u0192\u00f9\u2551', '\U0001f5fa'),  # 🗺
  @('\u00ad\u0192\u00f9\u00e4', '\U0001f4a5'),  # 💥
  @('\u00ad\u0192\u00d4\u00b9', '\U0001f4b9'),  # 💹
  @('\u00ad\u0192\u00c4\u00bb', '\U0001f4e1'),  # 📱 Twilio
  @('\u00ad\u0192\u00f6\u00ee', '\U0001f50e'),  # 🔌
  @('\u00ad\u0192\u00c4\u00bb', '\U0001f4f1'),  # 📱
  @('\u00ad\u0192\u00c4\u00ba', '\U0001f4ba'),  # 💺
  @('\u00ad\u0192\u00c4\u00be', '\U0001f4be'),  # 💾
  @('\u00ad\u0192\u00c5\u00bb', '\U0001f4db'),  # 📛
  @('\u00ad\u0192\u00c4\u00b7', '\U0001f4b7'),  # 💷
  @('\u00ad\u0192\u00c4\u00b0', '\U0001f4b0'),  # 💰
  @('\u00ad\u0192\u00c4\u00b9', '\U0001f4b9'),  # 💹
  @('\u00ad\u0192\u00c4\u0080', '\U0001f440'),  # 👀
  @('\u00ad\u0192\u00c5\u00b4', '\U0001f374'),  # 🍴
  @('\u00ad\u0192\u00c5\u00bc', '\U0001f4fc'),  # 📼? 
  @('\u00ad\u0192\u00c4\u2590', '\U0001f250'),  # 🉐
  @('\u00ad\u0192\u00c4\u2030', '\U0001f0a0'),  # misc
  @('\u00ad\u0192\u00c4\u00a0', '\U0001f0a0'),  # misc
  # Emoji variations
  @('\u00c2\u00b4\u00c2\u00a9\u00c5', '\ufe0f'),  # ´©Å variation selector
  @('\u00c2\u00b4\u00c2\u00a9\u00c5', '')          # strip variation combo
)

$count = 0
foreach ($pair in $replacements) {
    $before = $content
    $content = $content.Replace($pair[0], $pair[1])
    if ($content -ne $before) { 
        $count++
        Write-Host "Replaced: [$($pair[0])] -> [$($pair[1])]"
    }
}

Write-Host "Total substitution types made: $count"
[System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)
Write-Host "Done. File saved."
