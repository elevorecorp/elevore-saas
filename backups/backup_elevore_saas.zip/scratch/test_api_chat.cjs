async function main() {
  try {
    console.log("Testing production chat API with no client key...");
    const url = 'https://elevore-saas.vercel.app/api/chat';
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-gemini-key': ''
      },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: 'Eres un asistente' },
          { role: 'user', content: 'hola' }
        ],
        model: 'gemini-2.5-flash'
      })
    });

    console.log(`Status: ${response.status}`);
    const data = await response.text();
    console.log(`Response: ${data}`);
  } catch (err) {
    console.error("Request failed:", err);
  }
}

main();
