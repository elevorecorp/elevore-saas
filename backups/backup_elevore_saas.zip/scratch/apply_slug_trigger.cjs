const postgres = require('postgres');
const fs = require('fs');
const path = require('path');

const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    const sqlPath = path.join(__dirname, '../supabase_add_tenant_slug_trigger.sql');
    console.log(`Reading SQL script from: ${sqlPath}`);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');

    console.log("Applying tenant slug autogeneration trigger to database...");
    await sql.unsafe(sqlContent);

    console.log("✅ Slug autogeneration trigger applied successfully!");
  } catch (err) {
    console.error("❌ Failed to apply slug trigger:", err);
  } finally {
    await sql.end();
  }
}

main();
