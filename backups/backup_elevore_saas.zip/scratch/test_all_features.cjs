const postgres = require('postgres');
const puppeteer = require('puppeteer');

// DB connection
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  console.log("=== STARTING COMPREHENSIVE END-TO-END SaaS INTEGRATION TEST ===");
  
  let browser;
  let testMissionId;
  const tenantId = '4ec723ab-4612-4c23-a550-f220939ff1c4'; // Elevore tenant
  const adminOwnerId = 'b89f6eb7-624e-425e-a7cb-d3eadff78329'; // Admin user owner of tenant
  
  try {
    // 1. Insert clean test data for public proposal and workspace validations
    console.log("Inserting test mission...");
    const [result] = await sql`
      INSERT INTO elevore_missions (client_name, client_email, client_phone, status, tenant_id, address, service_type, total_price, deposit_paid)
      VALUES ('Test E2E Client', 'e2etest@gmail.com', '4075559999', 'scheduled', ${tenantId}, '789 E2E Blvd, Orlando, FL', 'Deep Cleaning', 150.00, 25.00)
      RETURNING id;
    `;
    testMissionId = result.id;
    console.log(`Test mission inserted with ID: ${testMissionId}`);

    // 2. Launch Puppeteer
    console.log('Launching browser via Puppeteer...');
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1050 });

    // Capture console output
    page.on('console', (msg) => {
      const text = msg.text();
      if (text.includes('[BROWSER CONSOLE]') || msg.type() === 'error' || text.includes('AI') || text.includes('Gemini')) {
        console.log(`[BROWSER CONSOLE] [${msg.type()}]: ${text}`);
      }
    });

    page.on('pageerror', (err) => {
      console.error(`[BROWSER RUNTIME EXCEPTION]:`, err.message, err.stack);
    });

    // Inject getter/setter on window.sb to mock Supabase authentication session
    console.log('Injecting session mocker into page...');
    await page.evaluateOnNewDocument((ownerId) => {
      let originalSb = null;
      Object.defineProperty(window, 'sb', {
        get() {
          return originalSb;
        },
        set(val) {
          originalSb = val;
          if (originalSb && originalSb.auth) {
            // Overwrite getSession to return mock authenticated session
            originalSb.auth.getSession = async () => {
              return {
                data: {
                  session: {
                    user: { id: ownerId, email: 'ceo@gmail.com', email_confirmed_at: '2026-01-01T00:00:00Z' }
                  }
                }
              };
            };
            // Overwrite onAuthStateChange to prevent loop errors
            originalSb.auth.onAuthStateChange = (cb) => {
              // Trigger once immediately
              cb('SIGNED_IN', {
                user: { id: ownerId, email: 'ceo@gmail.com' }
              });
              return { data: { subscription: { unsubscribe: () => {} } } };
            };
          }
        },
        configurable: true
      });
    }, adminOwnerId);

    const devServerUrl = 'http://localhost:5173/?view=brief';
    console.log(`Navigating to dashboard at ${devServerUrl} ...`);
    await page.goto(devServerUrl, { waitUntil: 'networkidle2', timeout: 35000 });
    
    // Wait for the app to finish loading database items
    await new Promise(r => setTimeout(r, 4000));
    
    // Check if we logged in as Admin successfully
    const pageTitle = await page.evaluate(() => document.body.innerText);
    if (!pageTitle.includes('DASHBOARD') && !pageTitle.includes('BRIEF')) {
      await page.screenshot({ path: 'scratch/auth_fail_debug.png' });
      throw new Error("Failed to authenticate as Admin using mock session.");
    }
    console.log("🎉 SUCCESS: Mock admin session injected and dashboard loaded successfully!");

    // --- TEST 1: ADMIN DASHBOARD (BRIEF) ---
    console.log('Testing Admin Dashboard (Brief)...');
    await page.screenshot({ path: 'scratch/view_brief.png' });
    console.log('Saved view_brief.png');

    // --- TEST 2: OPERATIONS VIEW AND SUBTABS ---
    console.log('Navigating to Operaciones view...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const opsBtn = buttons.find(b => b.textContent.toLowerCase().includes('operaciones'));
      if (opsBtn) opsBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    await page.screenshot({ path: 'scratch/view_operations_calendar.png' });
    console.log('Saved view_operations_calendar.png');

    // Test Meetings Subtab
    console.log('Navigating to Reuniones IA subtab...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const meetingsTab = buttons.find(b => b.textContent.toLowerCase().includes('reuniones ia'));
      if (meetingsTab) meetingsTab.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    await page.screenshot({ path: 'scratch/view_operations_meetings.png' });
    console.log('Saved view_operations_meetings.png');

    // Start meeting simulation
    console.log('Simulating speech meeting transcription...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const startBtn = buttons.find(b => b.textContent.toLowerCase().includes('iniciar reunión'));
      if (startBtn) startBtn.click();
    });
    await new Promise(r => setTimeout(r, 3000)); // wait for transcript simulator
    await page.screenshot({ path: 'scratch/meeting_active.png' });
    console.log('Saved meeting_active.png');

    // End meeting and generate summary
    console.log('Ending meeting and triggering AI Minutas generation...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const endBtn = buttons.find(b => b.textContent.toLowerCase().includes('finalizar y resumir'));
      if (endBtn) endBtn.click();
    });
    
    // Wait for AI to return summary (could fall back to local/heuristic)
    await new Promise(r => setTimeout(r, 6000));
    await page.screenshot({ path: 'scratch/meeting_finished_summary.png' });
    console.log('Saved meeting_finished_summary.png');

    // --- TEST 3: CRM VIEW ---
    console.log('Navigating to CRM / Clientes view...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const crmBtn = buttons.find(b => b.textContent.toLowerCase().includes('crm') || b.textContent.toLowerCase().includes('clientes'));
      if (crmBtn) crmBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    await page.screenshot({ path: 'scratch/view_crm.png' });
    console.log('Saved view_crm.png');

    // --- TEST 4: FINANCES VIEW ---
    console.log('Navigating to Finanzas & Equipos view...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const finBtn = buttons.find(b => b.textContent.toLowerCase().includes('finanzas') || b.textContent.toLowerCase().includes('equipos'));
      if (finBtn) finBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    await page.screenshot({ path: 'scratch/view_finances.png' });
    console.log('Saved view_finances.png');

    // --- TEST 5: CONFIGURATION VIEW ---
    console.log('Navigating to Configuración view...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const cfgBtn = buttons.find(b => b.textContent.toLowerCase().includes('configuracion') || b.textContent.toLowerCase().includes('configuración'));
      if (cfgBtn) cfgBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    await page.screenshot({ path: 'scratch/view_settings.png' });
    console.log('Saved view_settings.png');

    // --- TEST 6: AI ADVISOR MODAL CHAT ---
    console.log('Opening AI Advisor Chat...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const aiBtn = buttons.find(b => b.textContent.toLowerCase().includes('ai advisor') || b.textContent.toLowerCase().includes('advisor'));
      if (aiBtn) aiBtn.click();
    });
    await new Promise(r => setTimeout(r, 1500));
    await page.screenshot({ path: 'scratch/ai_advisor_open.png' });
    console.log('Saved ai_advisor_open.png');

    // Type prompt
    console.log('Sending message to AI Advisor...');
    await page.type('input[placeholder*="Pregúntame"]', 'Hola, hazme un análisis rápido del negocio.');
    await page.evaluate(() => {
      const inputEl = document.querySelector('input[placeholder*="Pregúntame"]');
      if (inputEl) {
        const parent = inputEl.parentElement;
        const sendBtn = parent.querySelector('button:last-child');
        if (sendBtn) sendBtn.click();
      }
    });
    await new Promise(r => setTimeout(r, 6000));
    await page.screenshot({ path: 'scratch/ai_advisor_replied.png' });
    console.log('Saved ai_advisor_replied.png');

    // Close AI Advisor modal
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      // Find close button by x icon or class
      const closeBtn = buttons.find(b => b.innerHTML.includes('x') || b.className.includes('fixed'));
      if (closeBtn) closeBtn.click();
    });
    await new Promise(r => setTimeout(r, 1000));

    // --- TEST 7: PUBLIC QUOTE PROPOSAL PAGE ---
    const proposalUrl = `http://localhost:5173/?mision=${testMissionId}`;
    console.log(`Navigating to public quote proposal page at: ${proposalUrl}`);
    await page.goto(proposalUrl, { waitUntil: 'networkidle2', timeout: 35000 });
    await new Promise(r => setTimeout(r, 3000));
    await page.screenshot({ path: 'scratch/view_public_proposal.png' });
    console.log('Saved view_public_proposal.png');

    // Verify page content contains proposal info
    const proposalBody = await page.evaluate(() => document.body.innerText);
    if (proposalBody.includes('Test E2E Client') || proposalBody.includes('Deep Cleaning')) {
      console.log("🎉 SUCCESS: Public quote proposal loaded and verified!");
    } else {
      throw new Error("Public proposal contents failed to load or verify.");
    }

    console.log("✨ ALL SECTIONS COMPLETED AND E2E VERIFIED SUCCESSFULLY! ✨");

  } catch (error) {
    console.error('❌ Error during E2E integration test:', error);
  } finally {
    if (browser) {
      await browser.close();
    }
    
    // 3. Clean up database
    if (testMissionId) {
      console.log("Cleaning up test database records...");
      await sql`
        DELETE FROM elevore_missions WHERE id = ${testMissionId};
      `;
      console.log("Database cleaned up successfully.");
    }
    
    await sql.end();
    process.exit(0);
  }
}

main();
