$path = 'c:\Users\Jose Mario\OneDrive\Escritorio\Nuevo proyecto Saas\src\App.jsx'
$content = [System.IO.File]::ReadAllText($path)
$bad = "{/* " + [char]0x2550 + [char]0x2550 + [char]0x2550 + " FINAL CTA " + [char]0x2550 + [char]0x2550 + [char]0x2550 + " */}}"
$good = "{/* " + [char]0x2550 + [char]0x2550 + [char]0x2550 + " FINAL CTA " + [char]0x2550 + [char]0x2550 + [char]0x2550 + " */}"
$fixed = $content.Replace($bad, $good)
if ($fixed -ne $content) {
    [System.IO.File]::WriteAllText($path, $fixed)
    Write-Host "Fixed successfully"
} else {
    Write-Host "Pattern not found, trying ASCII version"
    $bad2 = "{/* === FINAL CTA === */}}"
    $fixed2 = $content.Replace($bad2, "{/* === FINAL CTA === */}")
    if ($fixed2 -ne $content) {
        [System.IO.File]::WriteAllText($path, $fixed2)
        Write-Host "Fixed with ASCII version"
    } else {
        Write-Host "Could not find pattern to fix"
        # Show context around line 9531
        $lines = $content -split "`n"
        $lines[9529..9532] | ForEach-Object { Write-Host $_ }
    }
}
