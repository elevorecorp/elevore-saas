const fs = require('fs');
const path = require('path');
const postgres = require('postgres');

// Database connection string from scratch settings
const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    console.log("Reading supabase_secure_payouts.sql...");
    const sqlFilePath = path.join(__dirname, '..', 'supabase_secure_payouts.sql');
    const rawSql = fs.readFileSync(sqlFilePath, 'utf8');

    console.log("Applying SQL migration to Supabase...");
    
    // We execute the SQL statements. Using sql.unsafe permits running arbitrary multiline SQL statements.
    await sql.unsafe(rawSql);

    console.log("=== MIGRATION APPLIED SUCCESSFULLY! ===");
  } catch (err) {
    console.error("Migration failed:", err);
  } finally {
    await sql.end();
  }
}

main();
