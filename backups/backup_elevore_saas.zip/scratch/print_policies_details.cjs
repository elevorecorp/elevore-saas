const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    const policies = await sql`
      SELECT tablename, policyname, roles, cmd, qual, with_check 
      FROM pg_policies 
      WHERE schemaname = 'public'
      ORDER BY tablename, policyname;
    `;
    
    for (const p of policies) {
      console.log(`Table: ${p.tablename}`);
      console.log(`  Policy: ${p.policyname}`);
      console.log(`  Roles: ${JSON.stringify(p.roles)}`);
      console.log(`  Command: ${p.cmd}`);
      console.log(`  Qual: ${p.qual}`);
      console.log(`  With Check: ${p.with_check}`);
      console.log("--------------------------------------------------");
    }
  } catch (err) {
    console.error("Error fetching policies:", err);
  } finally {
    await sql.end();
  }
}

main();
