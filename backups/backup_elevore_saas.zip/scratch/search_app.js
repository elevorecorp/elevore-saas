const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'App.jsx');
const content = fs.readFileSync(filePath, 'utf8');

const query = 'loadTenantSettings';
const lines = content.split('\n');
lines.forEach((line, index) => {
  if (line.includes(query)) {
    console.log(`${index + 1}: ${line.trim()}`);
  }
});
