#!/usr/bin/env node
/**
 * Fix encoding corruption in App.jsx
 * 
 * The file was originally saved with UTF-8 characters, then at some point
 * was read as Windows-1252/CP850 and re-saved as UTF-8, causing multi-byte
 * UTF-8 sequences to be interpreted as individual Latin-1 chars.
 * 
 * This is the "Mojibake" problem: UTF-8 bytes interpreted as Latin-1/CP1252.
 * 
 * Strategy: Read the file as UTF-8, then fix known corrupted sequences
 * back to their correct Unicode characters.
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join('c:\\', 'Users', 'Jose Mario', 'OneDrive', 'Escritorio', 'Nuevo proyecto Saas', 'src', 'App.jsx');

console.log('Reading file...');
let content = fs.readFileSync(filePath, 'utf8');
console.log(`File size: ${content.length} chars`);

/**
 * These are mojibake patterns: UTF-8 sequences incorrectly decoded as Latin-1/CP1252
 * 
 * How mojibake works for UTF-8 -> Latin-1 misinterpretation:
 * - "—" (U+2014, em-dash) in UTF-8 is: E2 80 94
 *   Interpreted as Latin-1: Ã (C3=Ã) + â€ (80=€ in cp1252) + " (94=" in cp1252)
 *   But displayed as: â€" (common mojibake for em-dash)
 *   OR as: ÔÇö (if the UTF-8 bytes E2 80 96 are interpreted through another encoding)
 * 
 * The browser reports "ÔÇö" for em-dash. Let's find those exact bytes in the file.
 */

// Count occurrences first
const patterns = [
  // Based on browser report - these are the visible mojibake strings
  { bad: 'ÔÇö', good: '—', name: 'em-dash' },
  { bad: 'ÔåÆ', good: '→', name: 'right arrow' },
  { bad: 'ÔÇó', good: '•', name: 'bullet' },
  { bad: "ÔÇÖ", good: '\u2019', name: 'right single quote/apostrophe' },
  { bad: 'ÔÇô', good: '\u2013', name: 'en-dash' },
  { bad: 'ÔÇü', good: '\u00fc', name: 'u umlaut' },
  { bad: 'ÔÇÜ', good: '\u201c', name: 'left double quote' },
  { bad: 'ÔÇÝ', good: '\u201d', name: 'right double quote' },
  { bad: 'ÔÇ¦', good: '\u2026', name: 'ellipsis' },
  { bad: 'ÔÇ£', good: '\u201c', name: 'left double quote alt' },
  { bad: 'Ô£ô', good: '✓', name: 'check mark' },
  { bad: 'Ô£ò', good: '✗', name: 'x mark' },
  { bad: 'Ô£ë', good: '✉', name: 'envelope' },
  { bad: 'Ô£ì', good: '✍', name: 'writing hand' },
  { bad: 'ÔÜí', good: '⚡', name: 'lightning/zap' },
  { bad: 'Ôÿà', good: '★', name: 'black star' },
  { bad: 'Ô¡É', good: '⭐', name: 'white/medium star' },
  { bad: '┬®', good: '©', name: 'copyright' },
  { bad: '┬«', good: '®', name: 'registered' },
  // 4-byte emoji mojibake (these show as ­ƒXX sequences)
  { bad: '­ƒñû', good: '🤖', name: 'robot' },
  { bad: '­ƒº╣', good: '🧹', name: 'broom' },
  { bad: '­ƒöº', good: '🔧', name: 'wrench' },
  { bad: '­ƒÆ░', good: '💰', name: 'money bag' },
  { bad: '­ƒøí', good: '🏡', name: 'house garden' },
  { bad: '­ƒº╝', good: '🧼', name: 'soap' },
  { bad: '­ƒÜÇ', good: '🚀', name: 'rocket' },
  { bad: '­ƒÆ│', good: '💳', name: 'credit card' },
  { bad: '­ƒÆ╝', good: '💼', name: 'briefcase' },
  { bad: '­ƒÆ¼', good: '💬', name: 'speech bubble' },
  { bad: '­ƒÄ»', good: '📈', name: 'chart up' },
  { bad: '­ƒÄü', good: '📊', name: 'bar chart' },
  { bad: '­ƒôê', good: '🔌', name: 'electric plug' },
  { bad: '­ƒöî', good: '🔎', name: 'magnifying glass' },
  { bad: '­ƒù║', good: '🗺', name: 'world map' },
  { bad: '­ƒùä', good: '⚡', name: 'supabase lightning' },
  { bad: '­ƒô▒', good: '📱', name: 'mobile phone' },
  { bad: '­ƒÆ¡', good: '💡', name: 'light bulb' },
  { bad: '­ƒÆ▓', good: '💲', name: 'dollar sign' },
  { bad: '­ƒÅ░', good: '🆕', name: 'new badge' },
  { bad: '­ƒîî', good: '🎯', name: 'target' },
  { bad: '­ƒîÄ', good: '🎁', name: 'gift' },
  { bad: '­ƒöü', good: '🔑', name: 'key' },
  { bad: '­ƒôü', good: '📋', name: 'clipboard' },
  { bad: '­ƒôé', good: '📄', name: 'document' },
  { bad: '­ƒôÅ', good: '📅', name: 'calendar' },
  { bad: '­ƒôì', good: '📌', name: 'pin' },
  { bad: '­ƒôù', good: '📝', name: 'memo' },
  { bad: '­ƒôç', good: '📧', name: 'email' },
  { bad: '­ƒôê', good: '📊', name: 'chart' },
  { bad: '­ƒÅó', good: '🎓', name: 'graduation cap' },
  { bad: '­ƒÅÄ', good: '🎤', name: 'microphone' },
  { bad: '­ƒÄ▒', good: '📱', name: 'phone alt' },
  // Variation selectors (often appended after emoji)
  { bad: '´©Å', good: '\ufe0f', name: 'variation selector 16' },
];

let totalReplacements = 0;
patterns.forEach(({ bad, good, name }) => {
  const count = (content.split(bad).length - 1);
  if (count > 0) {
    content = content.split(bad).join(good);
    console.log(`  Fixed ${count}x "${name}" (${bad} -> ${good})`);
    totalReplacements += count;
  }
});

// Also strip leftover lone variation selectors that may have been left after emoji fixes
// These appear as invisible characters but can cause issues
const vsCount = (content.split('\ufe0f').length - 1);
console.log(`  Variation selector (U+FE0F) count in file: ${vsCount}`);

console.log(`\nTotal replacements: ${totalReplacements}`);
console.log('Writing fixed file...');
fs.writeFileSync(filePath, content, 'utf8');
console.log('Done! File saved successfully.');
