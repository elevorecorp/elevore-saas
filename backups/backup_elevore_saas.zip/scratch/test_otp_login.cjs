const postgres = require('postgres');
const puppeteer = require('puppeteer');

// DB connection
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  console.log("=== STARTING 2FA OTP LOGIN INTEGRATION TEST ===");
  
  let browser;
  let testMissionId;
  const testEmail = 'testotp@gmail.com';
  const testPhone = '4075551234';
  const testName = 'OTP Test Client';
  const tenantId = '4ec723ab-4612-4c23-a550-f220939ff1c4'; // Elevore tenant
  
  try {
    // 1. Insert clean test data
    console.log("Inserting test mission...");
    const [result] = await sql`
      INSERT INTO elevore_missions (client_name, client_email, client_phone, status, tenant_id, address, service_type)
      VALUES (${testName}, ${testEmail}, ${testPhone}, 'scheduled', ${tenantId}, '456 OTP Lane, Orlando, FL', 'Deep Cleaning')
      RETURNING id;
    `;
    testMissionId = result.id;
    console.log(`Test mission inserted with ID: ${testMissionId}`);

    // 2. Launch Puppeteer
    console.log('Launching browser via Puppeteer...');
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1000 });

    let capturedOtp = '';
    
    // Listen to console to capture the OTP code
    page.on('console', (msg) => {
      const text = msg.text();
      console.log(`[BROWSER CONSOLE] [${msg.type()}]: ${text}`);
      if (text.includes('[ELEVORE CLIENT AUTH OTP]:')) {
        const parts = text.split(':');
        capturedOtp = parts[1].trim();
        console.log(`🔍 Captured OTP Code from console: ${capturedOtp}`);
      }
    });

    page.on('pageerror', (err) => {
      console.error(`[BROWSER RUNTIME EXCEPTION]:`, err.message, err.stack);
    });

    const loginUrl = 'http://localhost:5173/?view=auth';
    console.log(`Navigating to ${loginUrl} ...`);
    await page.goto(loginUrl, { waitUntil: 'networkidle2', timeout: 35000 });

    // Click "Client Portal" tab button
    console.log('Clicking Client Portal tab...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const clientBtn = buttons.find(b => b.textContent.toLowerCase().includes('client'));
      if (clientBtn) {
        clientBtn.click();
      } else {
        console.error("Client Portal tab button not found!");
      }
    });
    
    await new Promise(r => setTimeout(r, 1000));

    // Fill Email and Phone
    console.log('Filling out client email and phone number...');
    await page.type('input[placeholder="client@example.com"]', testEmail);
    await page.type('input[placeholder*="(407)"]', testPhone);

    // Take screenshot of login form filled
    await page.screenshot({ path: 'scratch/otp_login_filled.png' });
    console.log('Saved otp_login_filled.png');

    // Click "Enviar Enlace Seguro →" button
    console.log('Submitting login request...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const submitBtn = buttons.find(b => b.textContent.includes('Enviar Enlace Seguro'));
      if (submitBtn) submitBtn.click();
    });

    // Wait for the OTP screen to appear and console to log the OTP code
    console.log('Waiting for OTP code to be generated...');
    await new Promise(r => setTimeout(r, 3000));

    if (!capturedOtp) {
      throw new Error('Failed to capture OTP code from browser console logs');
    }

    // Enter the captured OTP code
    console.log(`Entering captured OTP: ${capturedOtp}`);
    await page.type('input[placeholder="Ej: 1234"]', capturedOtp);

    await page.screenshot({ path: 'scratch/otp_entered.png' });
    console.log('Saved otp_entered.png');

    // Click submit OTP
    console.log('Submitting verification code...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const verifyBtn = buttons.find(b => b.textContent.includes('Verificar'));
      if (verifyBtn) verifyBtn.click();
    });

    // Wait for redirect and portal rendering
    console.log('Waiting for redirect to Client Portal...');
    await new Promise(r => setTimeout(r, 5000));

    // Verify we are in the Portal
    await page.screenshot({ path: 'scratch/portal_verification_success.png' });
    console.log('Saved portal_verification_success.png');
    
    const bodyText = await page.evaluate(() => document.body.innerText);
    if (bodyText.includes('OTP Test Client') || bodyText.includes('456 OTP Lane')) {
      console.log('🎉 SUCCESS: Client dashboard successfully loaded and verified! 🚀');
    } else {
      throw new Error('Verification failed: Client dashboard contents not found on page');
    }

  } catch (error) {
    console.error('❌ Error during OTP login test:', error);
  } finally {
    if (browser) {
      await browser.close();
    }
    
    // 3. Clean up database
    if (testMissionId) {
      console.log("Cleaning up test database records...");
      await sql`
        DELETE FROM elevore_missions WHERE id = ${testMissionId};
      `;
      console.log("Database cleaned up successfully.");
    }
    
    await sql.end();
    process.exit(0);
  }
}

main();
