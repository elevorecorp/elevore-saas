const postgres = require('postgres');
const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    console.log("Creating public.login_staff_secure function...");
    await sql`
      CREATE OR REPLACE FUNCTION public.login_staff_secure(
          p_email TEXT,
          p_passcode TEXT
      )
      RETURNS TABLE (
          id UUID,
          tenant_id UUID,
          name TEXT,
          role TEXT,
          staff_email TEXT,
          phone TEXT,
          payout_pct NUMERIC,
          wallet_balance NUMERIC,
          total_earned NUMERIC
      ) 
      LANGUAGE plpgsql
      SECURITY DEFINER
      AS $$
      BEGIN
          RETURN QUERY
          SELECT 
              s.id,
              s.tenant_id,
              s.name,
              s.role,
              s.staff_email,
              s.phone,
              s.payout_pct,
              s.wallet_balance,
              s.total_earned
          FROM public.staff_profiles s
          WHERE s.passcode = p_passcode
            AND (
              LOWER(TRIM(s.staff_email)) = LOWER(TRIM(p_email))
              OR LOWER(TRIM(s.name)) = LOWER(TRIM(p_email))
            );
      END;
      $$;
    `;

    console.log("Granting execution permissions to anon and authenticated roles...");
    await sql`
      GRANT EXECUTE ON FUNCTION public.login_staff_secure(TEXT, TEXT) TO anon, authenticated;
    `;

    console.log("RPC Function created and granted successfully!");
  } catch (err) {
    console.error("SQL Execution failed:", err);
  } finally {
    await sql.end();
  }
}
main();
