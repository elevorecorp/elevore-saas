const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("=== UPDATING CEO TENANT SUBSCRIPTION STATUS ===");
    
    // Update the 'jose mario' tenant subscription status
    const result = await sql`
      UPDATE tenants 
      SET stripe_subscription_status = 'active_vip', 
          trial_ends_at = '2099-12-31 23:59:59+00' 
      WHERE business_name ILIKE '%jose mario%'
      RETURNING id, business_name, stripe_subscription_status, trial_ends_at;
    `;
    
    console.log("Update result:", result);
    console.log("🎉 CEO Tenant successfully upgraded to Lifetime VIP in DB!");
  } catch (err) {
    console.error("Failed to update tenant status:", err);
  } finally {
    await sql.end();
  }
}
main();
