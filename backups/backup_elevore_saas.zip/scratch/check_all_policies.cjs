const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("=== ALL POLICIES IN PUBLIC SCHEMA ===");
    const policies = await sql`
      SELECT tablename, policyname, roles, cmd, qual, with_check 
      FROM pg_policies 
      WHERE schemaname = 'public'
      ORDER BY tablename, policyname;
    `;
    console.table(policies);
  } catch (err) {
    console.error("Error fetching policies:", err);
  } finally {
    await sql.end();
  }
}

main();
