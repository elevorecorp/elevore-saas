const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

// Test Configuration
const TENANT_A = '4ec723ab-4612-4c23-a550-f220939ff1c4'; // Elevore Empire
const TENANT_B = '6ff85aba-da6c-4992-83d3-b964e676b523'; // Test Cleaning LLC
const ADMIN_A_UID = 'b89f6eb7-624e-425e-a7cb-d3eadff78329';
const STAFF_A_UID = 'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1';
const INTRUDER_UID = 'b2b2b2b2-b2b2-b2b2-b2b2-b2b2-b2b2-b2b2b2b2';

async function executeTest(role, jwtClaims, testFn) {
  try {
    return await sql.begin(async tx => {
      if (role === 'anon') {
        await tx`SET LOCAL ROLE anon`;
      } else {
        await tx`SET LOCAL ROLE authenticated`;
      }
      
      if (jwtClaims) {
        await tx`SELECT set_config('request.jwt.claims', ${JSON.stringify(jwtClaims)}, true)`;
      } else {
        await tx`SELECT set_config('request.jwt.claims', NULL, true)`;
      }
      
      return await testFn(tx);
    });
  } catch (err) {
    return { error: err.message };
  }
}

async function main() {
  console.log("==================================================================");
  console.log("🛡️ INICIANDO SUITE DE PRUEBAS DE SEGURIDAD RLS / RBAC");
  console.log("==================================================================");

  let passed = 0;
  let failed = 0;

  function report(name, condition, info = '') {
    if (condition) {
      console.log(`✅ [PASS] ${name} ${info}`);
      passed++;
    } else {
      console.log(`❌ [FAIL] ${name} ${info}`);
      failed++;
    }
  }

  // ----------------------------------------------------
  // 1. ANONYMOUS ROLE TESTS
  // ----------------------------------------------------
  console.log("\n--- [1] Pruebas de Acceso Anónimo (Público) ---");

  // 1.1 Leer clientes
  const anonClients = await executeTest('anon', null, tx => tx`SELECT * FROM public.clients`);
  report(
    "Anon no puede leer clientes",
    anonClients.error || (Array.isArray(anonClients) && anonClients.length === 0),
    anonClients.error ? `(${anonClients.error})` : `(Retornó ${anonClients.length} filas)`
  );

  // 1.2 Insertar leads
  const anonInsertLead = await executeTest('anon', null, tx => tx`
    INSERT INTO public.elevore_missions (tenant_id, client_name, service_type, status, total_price)
    VALUES (${TENANT_A}, 'Lead de Pruebas RLS', 'Regular', 'lead', 120) RETURNING id
  `);
  const insertedLeadId = (Array.isArray(anonInsertLead) && anonInsertLead.length > 0) ? anonInsertLead[0].id : null;
  report("Anon puede crear cotizaciones con estado 'lead'", insertedLeadId !== null);

  // 1.3 Insertar misiones completadas
  const anonInsertCompleted = await executeTest('anon', null, tx => tx`
    INSERT INTO public.elevore_missions (tenant_id, client_name, service_type, status, total_price)
    VALUES (${TENANT_A}, 'Hack Intruso', 'Regular', 'completed', 500) RETURNING id
  `);
  report(
    "Anon NO puede crear misiones con estado 'completed' (Bloqueado por RLS)",
    anonInsertCompleted.error !== undefined,
    anonInsertCompleted.error ? `(Bloqueado: ${anonInsertCompleted.error})` : '(No bloqueado)'
  );

  // 1.4 Limpiar el lead de prueba insertado
  if (insertedLeadId) {
    await executeTest('anon', null, tx => tx`DELETE FROM public.elevore_missions WHERE id = ${insertedLeadId}`);
  }

  // ----------------------------------------------------
  // 2. ADMIN A ROLE TESTS (Elevore Empire)
  // ----------------------------------------------------
  console.log("\n--- [2] Pruebas de Acceso Administrador (Tenant A) ---");
  const adminClaims = {
    sub: ADMIN_A_UID,
    role: 'authenticated',
    user_metadata: { tenant_id: TENANT_A, role: 'admin', name: 'jose mario Admin' }
  };

  // 2.1 Leer clientes
  const adminClients = await executeTest('authenticated', adminClaims, tx => tx`SELECT * FROM public.clients`);
  report(
    "Admin puede leer todos los clientes de su tenant",
    Array.isArray(adminClients) && adminClients.length > 0,
    `(${adminClients.length} clientes encontrados)`
  );

  // 2.2 Leer misiones
  const adminMissions = await executeTest('authenticated', adminClaims, tx => tx`SELECT * FROM public.elevore_missions`);
  report(
    "Admin puede leer todas las misiones de su tenant",
    Array.isArray(adminMissions) && adminMissions.length > 0,
    `(${adminMissions.length} misiones encontradas)`
  );

  // ----------------------------------------------------
  // 3. CROSS-TENANT ATTACK (Admin B leyendo Tenant A)
  // ----------------------------------------------------
  console.log("\n--- [3] Pruebas de Aislamiento Cruzado (Cross-Tenant) ---");
  const intruderClaims = {
    sub: INTRUDER_UID,
    role: 'authenticated',
    user_metadata: { tenant_id: TENANT_B, role: 'admin', name: 'Intruder Admin' }
  };

  const crossClients = await executeTest('authenticated', intruderClaims, tx => tx`
    SELECT * FROM public.clients WHERE tenant_id = ${TENANT_A}
  `);
  report(
    "Intruso de Tenant B no puede leer clientes de Tenant A",
    crossClients.error || (Array.isArray(crossClients) && crossClients.length === 0),
    crossClients.error ? `(${crossClients.error})` : `(Retornó ${crossClients.length} filas)`
  );

  const crossMissions = await executeTest('authenticated', intruderClaims, tx => tx`
    SELECT * FROM public.elevore_missions WHERE tenant_id = ${TENANT_A}
  `);
  report(
    "Intruso de Tenant B no puede leer misiones de Tenant A",
    crossMissions.error || (Array.isArray(crossMissions) && crossMissions.length === 0),
    crossMissions.error ? `(${crossMissions.error})` : `(Retornó ${crossMissions.length} filas)`
  );

  // ----------------------------------------------------
  // 4. ROLE-BASED ACCESS CONTROL (Staff A - isaac)
  // ----------------------------------------------------
  console.log("\n--- [4] Pruebas de Rol Empleado (Staff A) - Vulnerabilidad Auditoría ---");
  const staffClaims = {
    sub: STAFF_A_UID,
    role: 'authenticated',
    user_metadata: { tenant_id: TENANT_A, role: 'staff', name: 'isaac' }
  };

  // 4.1 Leer base de clientes (Debe fallar / ser bloqueado en producción)
  const staffClients = await executeTest('authenticated', staffClaims, tx => tx`SELECT * FROM public.clients`);
  const clientReadBlocked = staffClients.error !== undefined || (Array.isArray(staffClients) && staffClients.length === 0);
  report(
    "Staff no tiene acceso a leer la tabla 'clients' (Debe ser denegado)",
    clientReadBlocked,
    clientReadBlocked ? "(Acceso bloqueado)" : `⚠️ VULNERABILIDAD: ¡El staff pudo leer ${staffClients.length} clientes!`
  );

  // 4.2 Leer misiones asignadas a otros (Debe retornar solo misiones donde figure 'isaac' o estar bloqueado)
  const staffMissions = await executeTest('authenticated', staffClaims, tx => tx`SELECT id, team_assigned FROM public.elevore_missions`);
  let hasOtherMissions = false;
  if (Array.isArray(staffMissions) && staffMissions.length > 0) {
    hasOtherMissions = staffMissions.some(m => !m.team_assigned || !m.team_assigned.toLowerCase().includes('isaac'));
  }
  report(
    "Staff no tiene acceso a ver misiones asignadas a otros trabajadores (Debe filtrar u ocultar)",
    !hasOtherMissions,
    hasOtherMissions ? "⚠️ VULNERABILIDAD: ¡El staff puede ver misiones ajenas!" : "(Acceso filtrado/seguro)"
  );

  // 4.3 Modificar perfil de staff (Modificar balance financiero)
  // Intentaremos actualizar el balance de isaac desde el contexto del staff
  const staffUpdateProfile = await executeTest('authenticated', staffClaims, tx => tx`
    UPDATE public.staff_profiles 
    SET wallet_balance = 9999.99 
    WHERE name = 'isaac'
  `);
  const staffUpdateBlocked = staffUpdateProfile.error !== undefined || (staffUpdateProfile && staffUpdateProfile.count === 0);
  report(
    "Staff no puede actualizar balances o comisiones en 'staff_profiles' (Debe ser bloqueado)",
    staffUpdateBlocked,
    staffUpdateBlocked ? "(Acceso bloqueado)" : "⚠️ VULNERABILIDAD: ¡El staff pudo modificar su balance!"
  );

  console.log("\n==================================================================");
  console.log(`📊 RESUMEN: ${passed} pruebas exitosas, ${failed} fallidas.`);
  console.log("==================================================================");

  await sql.end();
}

main();
