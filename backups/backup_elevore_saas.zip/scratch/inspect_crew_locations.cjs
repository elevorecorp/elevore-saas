const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("=== CREW LOCATIONS ===");
    const locations = await sql`SELECT * FROM crew_locations;`;
    console.table(locations);
  } catch (err) {
    console.error("Database query failed:", err.message);
  } finally {
    await sql.end();
  }
}
main();
