const postgres = require('postgres');
const fs = require('fs');
const path = require('path');

const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    const sqlPath = path.join(__dirname, '../supabase_fix_onboarding_rbac.sql');
    console.log(`Reading SQL script from: ${sqlPath}`);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');

    console.log("Applying RLS/RBAC onboarding fix to database...");
    await sql.unsafe(sqlContent);

    console.log("✅ RLS/RBAC onboarding fix applied successfully!");
  } catch (err) {
    console.error("❌ Failed to apply onboarding fix:", err);
  } finally {
    await sql.end();
  }
}

main();
