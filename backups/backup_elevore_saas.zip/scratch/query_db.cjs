const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("=== DB QUERY START ===");
    const tenants = await sql`SELECT * FROM tenants LIMIT 5;`;
    console.log("Tenants found:", tenants);

    const staff = await sql`SELECT * FROM staff_profiles LIMIT 5;`;
    console.log("Staff profiles found:", staff);
  } catch (err) {
    console.error("DB Query error:", err);
  } finally {
    await sql.end();
  }
}
main();
