const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("Resetting isaac balance...");
    const res = await sql`UPDATE public.staff_profiles SET wallet_balance = 150.00 WHERE name = 'isaac'`;
    console.log("Success! Rows updated:", res.count);
  } catch (err) {
    console.error(err);
  } finally {
    await sql.end();
  }
}
main();
