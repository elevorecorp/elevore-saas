const postgres = require('postgres');
const fs = require('fs');
const path = require('path');

const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    const sqlPath = path.join(__dirname, '../supabase_add_ai_settings.sql');
    console.log(`Reading SQL script from: ${sqlPath}`);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');

    console.log("Applying AI settings columns to database...");
    await sql.unsafe(sqlContent);

    console.log("✅ AI Settings applied successfully!");
  } catch (err) {
    console.error("❌ Failed to apply AI Settings:", err);
  } finally {
    await sql.end();
  }
}

main();
