const fs = require('fs');
const path = require('path');

const appPath = path.join(__dirname, '..', 'src', 'App.jsx');

function search(query) {
  console.log(`Searching for "${query}" in App.jsx...`);
  try {
    let content = fs.readFileSync(appPath, 'utf8');
    
    // Check if it's UTF-16LE
    if (content.startsWith('\uFEFF') || content.startsWith('\xFF\xFE') || content.includes('\u0000')) {
      console.log("Detected UTF-16 or null bytes. Re-reading as utf16le...");
      content = fs.readFileSync(appPath, 'utf16le');
    }
    
    const lines = content.split('\n');
    let matches = 0;
    
    lines.forEach((line, idx) => {
      if (line.toLowerCase().includes(query.toLowerCase())) {
        console.log(`${idx + 1}: ${line.trim().substring(0, 120)}`);
        matches++;
        if (matches >= 20) {
          console.log("...more matches truncated");
          return;
        }
      }
    });
    console.log(`Total matches found: ${matches}`);
  } catch (err) {
    console.error("Search failed:", err);
  }
}

const query = process.argv[2] || 'HyperDriveTab';
search(query);
