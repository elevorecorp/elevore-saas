const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

const TENANT_A = '4ec723ab-4612-4c23-a550-f220939ff1c4';
const STAFF_A_UID = 'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1';

async function main() {
  try {
    const staffClaims = {
      sub: STAFF_A_UID,
      role: 'authenticated',
      user_metadata: { tenant_id: TENANT_A, role: 'staff', name: 'isaac' }
    };

    console.log("Before update (Admin view):");
    const before = await sql`SELECT id, name, wallet_balance FROM public.staff_profiles WHERE name = 'isaac'`;
    console.table(before);

    console.log("Running update as staff...");
    const result = await sql.begin(async tx => {
      await tx`SET LOCAL ROLE authenticated`;
      await tx`SELECT set_config('request.jwt.claims', ${JSON.stringify(staffClaims)}, true)`;
      return await tx`
        UPDATE public.staff_profiles 
        SET wallet_balance = 9999.99 
        WHERE name = 'isaac'
      `;
    });

    console.log("Result object:", result);
    console.log("Result count:", result.count);

    console.log("After update (Admin view):");
    const after = await sql`SELECT id, name, wallet_balance FROM public.staff_profiles WHERE name = 'isaac'`;
    console.table(after);

  } catch (err) {
    console.error(err);
  } finally {
    await sql.end();
  }
}

main();
