const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    const users = await sql`SELECT id, email, raw_user_meta_data FROM auth.users`;
    console.table(users.map(u => ({ id: u.id, email: u.email, name: u.raw_user_meta_data?.name })));
  } catch (err) {
    console.error(err);
  } finally {
    await sql.end();
  }
}
main();
