const { createClient } = require('@supabase/supabase-js');
const postgres = require('postgres');

const supabaseUrl = "https://ceijlgurveaalvjmptns.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNlaWpsZ3VydmVhYWx2am1wdG5zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY4MTYwMzEsImV4cCI6MjA5MjM5MjAzMX0.XaPMpXxwMKRM09YN9kroF-gnISM2gBn29wi2R2UdOIc";
const sb = createClient(supabaseUrl, supabaseAnonKey);

const dbSql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  console.log("==================================================================");
  console.log("🧪 TESTING SECURITY AND SECURE RPC FUNCTIONS");
  console.log("==================================================================");

  const staffId = 'ce108bba-3ec3-4ea8-90b6-eb1319a2f842'; // Marcela
  const correctPasscode = '1010';
  const wrongPasscode = '9999';
  const tenantId = '4ec723ab-4612-4c23-a550-f220939ff1c4';

  // 1. Direct anonymous SELECT should be BLOCKED (return 0 rows or error)
  console.log("\n1. Testing direct anonymous select on staff_profiles...");
  const { data: staffList, error: stErr } = await sb.from('staff_profiles').select('*');
  console.log("Result error status:", stErr ? stErr.message : "No error");
  console.log("Rows returned:", staffList ? staffList.length : 0);
  if (!staffList || staffList.length === 0) {
    console.log("✅ SECURE: Direct select is blocked or returned empty.");
  } else {
    console.log("⚠️ VULNERABLE: Direct select was allowed and returned rows!");
  }

  // 2. Direct anonymous SELECT on staff_payouts should be BLOCKED
  console.log("\n2. Testing direct anonymous select on staff_payouts...");
  const { data: payoutsList, error: payErr } = await sb.from('staff_payouts').select('*');
  console.log("Result error status:", payErr ? payErr.message : "No error");
  console.log("Rows returned:", payoutsList ? payoutsList.length : 0);
  if (!payoutsList || payoutsList.length === 0) {
    console.log("✅ SECURE: Direct payouts select is blocked or returned empty.");
  } else {
    console.log("⚠️ VULNERABLE: Direct payouts select was allowed!");
  }

  // 3. RPC: get_staff_profile_secure with CORRECT PIN
  console.log("\n3. Calling get_staff_profile_secure with CORRECT PIN...");
  const { data: profileCorrect, error: rpcErr1 } = await sb.rpc('get_staff_profile_secure', {
    p_staff_id: staffId,
    p_passcode: correctPasscode
  });
  console.log("RPC Error status:", rpcErr1 ? rpcErr1.message : "No error");
  console.log("RPC Data returned:", profileCorrect);
  if (profileCorrect && profileCorrect.length > 0 && profileCorrect[0].name === 'Marcela') {
    console.log("✅ SUCCESS: Correctly returned profile securely.");
  } else {
    console.log("❌ FAILURE: Could not retrieve profile with correct passcode.");
  }

  // 4. RPC: get_staff_profile_secure with WRONG PIN
  console.log("\n4. Calling get_staff_profile_secure with WRONG PIN...");
  const { data: profileWrong, error: rpcErr2 } = await sb.rpc('get_staff_profile_secure', {
    p_staff_id: staffId,
    p_passcode: wrongPasscode
  });
  console.log("RPC Error status:", rpcErr2 ? rpcErr2.message : "No error");
  console.log("RPC Data returned:", profileWrong);
  if (!profileWrong || profileWrong.length === 0) {
    console.log("✅ SECURE: Rejected wrong passcode.");
  } else {
    console.log("❌ FAILURE: Exposed profile to wrong passcode!");
  }

  // 5. RPC: complete_mission_secure and commission calculation
  console.log("\n5. Testing complete_mission_secure...");
  // Create a temporary test mission directly in database using dbSql (bypassing RLS for setup)
  console.log("Setting up a test mission in the database...");
  const [testMission] = await dbSql`
    INSERT INTO public.elevore_missions (tenant_id, client_name, service_type, status, total_price, team_assigned)
    VALUES (${tenantId}, 'Test Client Security', 'Deep Cleaning Extra', 'scheduled', 200.00, 'Marcela')
    RETURNING id;
  `;
  const testMissionId = testMission.id;
  console.log("Test mission created with ID:", testMissionId);

  // Call the complete_mission_secure RPC
  console.log("Executing complete_mission_secure RPC anonymously...");
  const { data: updateRes, error: rpcErr3 } = await sb.rpc('complete_mission_secure', {
    p_mission_id: testMissionId,
    p_staff_id: staffId,
    p_passcode: correctPasscode
  });
  console.log("RPC Error status:", rpcErr3 ? rpcErr3.message : "No error");
  console.log("Balances returned after completion:", updateRes);

  if (updateRes && updateRes.length > 0) {
    console.log("✅ SUCCESS: Mission completed and commission calculated on server!");
  } else {
    console.log("❌ FAILURE: Could not complete mission securely.");
  }

  // Verify mission status and staff balance in the DB
  const [missionDb] = await dbSql`SELECT status FROM public.elevore_missions WHERE id = ${testMissionId}`;
  console.log("Mission status in DB:", missionDb.status);

  // Clean up test mission
  console.log("Cleaning up test mission...");
  await dbSql`DELETE FROM public.elevore_missions WHERE id = ${testMissionId}`;

  // 6. RPC: request_cashout_secure
  console.log("\n6. Testing request_cashout_secure...");
  // Read current balance
  const [staffDbBefore] = await dbSql`SELECT wallet_balance FROM public.staff_profiles WHERE id = ${staffId}`;
  const balanceBefore = Number(staffDbBefore.wallet_balance);
  console.log("Staff wallet balance before cashout:", balanceBefore);

  if (balanceBefore > 0) {
    const { data: cashoutRes, error: rpcErr4 } = await sb.rpc('request_cashout_secure', {
      p_staff_id: staffId,
      p_passcode: correctPasscode
    });
    console.log("Cashout RPC Error status:", rpcErr4 ? rpcErr4.message : "No error");
    console.log("Cashout RPC Result:", cashoutRes);

    const [staffDbAfter] = await dbSql`SELECT wallet_balance FROM public.staff_profiles WHERE id = ${staffId}`;
    console.log("Staff wallet balance after cashout:", staffDbAfter.wallet_balance);

    if (Number(staffDbAfter.wallet_balance) === 0) {
      console.log("✅ SUCCESS: Wallet balance reset to 0 in database!");
      
      // Clean up the created payout record so we don't mess up history
      console.log("Cleaning up payout record...");
      await dbSql`DELETE FROM public.staff_payouts WHERE staff_id = ${staffId} AND amount = ${balanceBefore}`;
      
      // Restore previous wallet balance
      console.log("Restoring original balance to test staff...");
      await dbSql`UPDATE public.staff_profiles SET wallet_balance = ${balanceBefore} WHERE id = ${staffId}`;
    } else {
      console.log("❌ FAILURE: Wallet balance was not reset to 0.");
    }
  } else {
    console.log("Skipping cashout test because balance is 0.");
  }

  await dbSql.end();
  console.log("\n==================================================================");
}

main();
