const postgres = require('postgres');
const puppeteer = require('puppeteer');

const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  console.log("=== STARTING E2E TEST: BOOK DRAFT & NEGOTIATE LATER FLOW ===");
  
  let browser;
  let testMissionId;
  const tenantId = '4ec723ab-4612-4c23-a550-f220939ff1c4'; // Elevore tenant
  
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1050 });

    // Capture browser console logs
    page.on('console', (msg) => {
      const text = msg.text();
      if (text.includes('AI') || text.includes('Negotiat') || msg.type() === 'error') {
        console.log(`[BROWSER CONSOLE] [${msg.type()}]: ${text}`);
      }
    });

    const bookingUrl = `http://localhost:5173/?book=true&t=${tenantId}`;
    console.log(`Navigating to public booking page: ${bookingUrl}`);
    await page.goto(bookingUrl, { waitUntil: 'networkidle2', timeout: 35000 });
    await new Promise(r => setTimeout(r, 2000));

    // Fill personal details
    console.log("Filling personal info...");
    await page.type('input[placeholder="Ej. Juan Pérez"]', 'E2E Draft Client');
    await page.type('input[placeholder="+1 (407) 555-0199"]', '4075558888');
    await page.type('input[placeholder="juan@ejemplo.com"]', 'e2edraft@gmail.com');
    await page.type('input[placeholder="100 E Pine St, Orlando, FL 32801"]', '123 E2E Draft St, Orlando, FL');

    // Fill date
    console.log("Selecting date...");
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 2);
    const dateStr = tomorrow.toISOString().split('T')[0];
    await page.evaluate((dVal) => {
      // Find date input and set value
      const dateInputs = Array.from(document.querySelectorAll('input[type="date"]'));
      if (dateInputs.length > 0) {
        dateInputs[0].value = dVal;
        const event = new Event('change', { bubbles: true });
        dateInputs[0].dispatchEvent(event);
      }
    }, dateStr);
    
    await new Promise(r => setTimeout(r, 1000));

    // Take screenshot of filled booking widget
    await page.screenshot({ path: 'scratch/portal_booking_filled.png' });
    console.log('Saved portal_booking_filled.png');

    // Click on Book Draft & Negotiate button
    console.log('Clicking "Cotizar y Negociar Descuento con IA"...');
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const draftBtn = buttons.find(b => b.textContent.includes('Cotizar y Negociar'));
      if (draftBtn) draftBtn.click();
    });

    console.log('Waiting for redirection to proposal page...');
    // We expect the URL to change to a page containing ?propuesta=
    let redirected = false;
    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const currentUrl = page.url();
      if (currentUrl.includes('propuesta=')) {
        redirected = true;
        const proposalId = new URL(currentUrl).searchParams.get('propuesta');
        testMissionId = proposalId;
        console.log(`🎉 SUCCESS: Redirected to proposal page for quote ID: ${testMissionId}`);
        break;
      }
    }

    if (!redirected) {
      await page.screenshot({ path: 'scratch/portal_booking_redirect_failed.png' });
      throw new Error("Redirect to proposal page failed.");
    }

    // Wait for proposal page to finish loading
    await new Promise(r => setTimeout(r, 4000));
    await page.screenshot({ path: 'scratch/proposal_loaded.png' });
    console.log('Saved proposal_loaded.png');

    const proposalBody = await page.evaluate(() => document.body.innerText);
    if (!proposalBody.includes('E2E DRAFT CLIENT') && !proposalBody.includes('E2E Draft Client')) {
      throw new Error("Proposal page does not contain client name.");
    }
    console.log("🎉 SUCCESS: Proposal loaded correctly with client name.");

    // Chat negotiation interaction
    console.log("Interacting with AI Closer...");
    await page.type('input[placeholder*="Pregunta"]', 'Hola, soy estudiante, ¿puedes darme un descuento del 15%?');
    await page.evaluate(() => {
      const inputEl = document.querySelector('input[placeholder*="Pregunta"]');
      if (inputEl) {
        const parent = inputEl.parentElement;
        const sendBtn = parent.querySelector('button');
        if (sendBtn) sendBtn.click();
      }
    });

    await new Promise(r => setTimeout(r, 5000));
    await page.screenshot({ path: 'scratch/proposal_chat_sent.png' });
    console.log('Saved proposal_chat_sent.png');

    console.log("✨ ALL TEST STEPS PASSED SUCCESSFULLY! ✨");

  } catch (error) {
    console.error('❌ Error during E2E test:', error);
  } finally {
    if (browser) {
      await browser.close();
    }
    
    // Clean up test data from DB
    if (testMissionId) {
      console.log(`Cleaning up test record: ${testMissionId}`);
      await sql`
        DELETE FROM elevore_missions WHERE id = ${testMissionId};
      `;
      console.log("Database cleaned up successfully.");
    }
    
    await sql.end();
    process.exit(0);
  }
}

main();
