const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    console.log("=== TENANT SETTINGS ===");
    const settings = await sql`SELECT * FROM tenant_settings;`;
    console.log(settings);
  } catch (err) {
    console.error("Database query failed:", err);
  } finally {
    await sql.end();
  }
}
main();
