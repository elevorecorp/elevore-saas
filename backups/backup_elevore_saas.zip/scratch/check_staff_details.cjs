const postgres = require('postgres');
const connectionString = 'postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres';
const sql = postgres(connectionString);

async function main() {
  try {
    console.log("=== ALL STAFF PROFILES ===");
    const profiles = await sql`SELECT id, name, passcode, staff_email, user_id, tenant_id FROM staff_profiles;`;
    console.table(profiles);
  } catch (err) {
    console.error("Query failed:", err);
  } finally {
    await sql.end();
  }
}
main();
