import { customType } from "drizzle-orm/pg-core";

console.log("customType imported successfully:", customType);
