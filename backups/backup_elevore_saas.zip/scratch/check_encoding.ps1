$path = 'c:\Users\Jose Mario\OneDrive\Escritorio\Nuevo proyecto Saas\src\App.jsx'
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

$idx = $content.IndexOf('Today Only')
if ($idx -gt 0) {
    Write-Host ('Found Today Only at index: ' + $idx)
    $snippet = $content.Substring([Math]::Max(0, $idx-60), 140)
    Write-Host ('Context: ' + $snippet)
} else {
    Write-Host 'NOT FOUND'
}

$bannerIdx = $content.IndexOf('LIMITED OFFER')
if ($bannerIdx -gt 0) {
    Write-Host ('Found LIMITED OFFER at: ' + $bannerIdx)
    $snippet2 = $content.Substring($bannerIdx, 120)
    Write-Host ('Banner: ' + $snippet2)
} else {
    Write-Host 'LIMITED OFFER not found'
}

# Check for corruption pattern
$count1 = ([regex]::Matches($content, 'ÔÇö')).Count
Write-Host ('Corrupted em-dash count: ' + $count1)

# Check for real em-dash
$emChar = [char]0x2014
$count2 = ([regex]::Matches($content, $emChar)).Count
Write-Host ('Real em-dash count: ' + $count2)
