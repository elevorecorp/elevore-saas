const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = "https://ceijlgurveaalvjmptns.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNlaWpsZ3VydmVhYWx2am1wdG5zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY4MTYwMzEsImV4cCI6MjA5MjM5MjAzMX0.XaPMpXxwMKRM09YN9kroF-gnISM2gBn29wi2R2UdOIc";

const sb = createClient(supabaseUrl, supabaseAnonKey);

async function runTest() {
  const rand = Math.random().toString(36).substring(7);
  const email = `test_ceo_${rand}@elevore.com`;
  const password = `password_${rand}_123`;
  const company = `Test Company ${rand}`;
  const ownerName = `Jose CEO ${rand}`;
  const phone = `+1407555${Math.floor(1000 + Math.random() * 9000)}`;

  console.log(`Starting signup simulation with email: ${email}`);

  try {
    // 1. Sign up user
    console.log("Step 1: sb.auth.signUp...");
    const { data: signUpData, error: signUpError } = await sb.auth.signUp({
      email: email,
      password: password,
    });

    if (signUpError) {
      console.error("❌ Sign up failed:", signUpError.message);
      return;
    }

    const user = signUpData?.user;
    const session = signUpData?.session;
    console.log(`✅ Sign up succeeded. User ID: ${user ? user.id : 'NONE'}, Session present: ${!!session}`);

    if (!user) {
      console.error("❌ User object is null after signup.");
      return;
    }

    // Initialize authenticated client using the session/access token if present
    let authSb = sb;
    if (session?.access_token) {
      console.log("Creating authenticated Supabase client...");
      authSb = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: `Bearer ${session.access_token}`
          }
        }
      });
    } else {
      console.log("⚠️ No session returned in signUp (possibly because email confirmation is enabled). Testing if insertion is allowed using anon client/auth.setSession if needed.");
      // We can also try to log in immediately to get a session (since password was just set)
      console.log("Attempting sign in to get active session...");
      const { data: signInData, error: signInError } = await sb.auth.signInWithPassword({
        email,
        password
      });
      if (signInError) {
        console.warn("⚠️ Sign in failed (confirm email might be required):", signInError.message);
      } else if (signInData?.session) {
        console.log("✅ Sign in succeeded! Authenticating client...");
        authSb = createClient(supabaseUrl, supabaseAnonKey, {
          global: {
            headers: {
              Authorization: `Bearer ${signInData.session.access_token}`
            }
          }
        });
      }
    }

    // 2. Create the tenant
    console.log("Step 2: Inserting tenant...");
    const { data: tenantData, error: tErr } = await authSb.from('tenants').insert([
      { business_name: company, owner_id: user.id }
    ]).select().maybeSingle();

    if (tErr) {
      console.error("❌ Tenant creation failed:", tErr.message, JSON.stringify(tErr));
      return;
    }
    console.log(`✅ Tenant created. Tenant ID: ${tenantData ? tenantData.id : 'NONE'}`);

    if (!tenantData) {
      console.error("❌ Tenant data was not returned.");
      return;
    }

    // 3. Create the admin staff profile
    console.log("Step 3: Inserting staff profile...");
    const { data: staffData, error: sErr } = await authSb.from('staff_profiles').insert([
      { 
        tenant_id: tenantData.id, 
        user_id: user.id, 
        name: ownerName, 
        role: 'admin', 
        passcode: '2026' 
      }
    ]).select();

    if (sErr) {
      console.error("❌ Staff profile creation failed:", sErr.message, JSON.stringify(sErr));
      return;
    }
    console.log(`✅ Staff profile created. Staff ID: ${staffData ? JSON.stringify(staffData) : 'NONE'}`);

    console.log("🎉 ALL STEPS COMPLETED SUCCESSFULY!");

  } catch (error) {
    console.error("🔥 System Error during test:", error);
  }
}

runTest();
