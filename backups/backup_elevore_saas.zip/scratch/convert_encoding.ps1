$srcPath = 'c:\Users\Jose Mario\OneDrive\Escritorio\Nuevo proyecto Saas\src\App.jsx'
$origPath = 'c:\Users\Jose Mario\OneDrive\Escritorio\Nuevo proyecto Saas\scratch\App.jsx.orig'

# Read the original git version (UTF-16LE from git show redirect)
$content = [System.IO.File]::ReadAllText($origPath, [System.Text.Encoding]::Unicode)

# Write back as UTF-8
[System.IO.File]::WriteAllText($srcPath, $content, [System.Text.Encoding]::UTF8)

Write-Host "Converted successfully. File size: $((Get-Item $srcPath).Length) bytes"
Write-Host "First line: $($content.Substring(0, [Math]::Min(80, $content.Length)))"
