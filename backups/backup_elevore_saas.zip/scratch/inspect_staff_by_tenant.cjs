const postgres = require('postgres');
const sql = postgres('postgres://postgres:lXBr7lsOvmWpGGQW@db.ceijlgurveaalvjmptns.supabase.co:6543/postgres');

async function main() {
  try {
    const tenantId = '906b3554-dca0-40e3-a653-90d003275f8d';
    console.log("=== STAFF PROFILES FOR JOSE MARIO TENANT ===");
    const staff = await sql`SELECT * FROM staff_profiles WHERE tenant_id = ${tenantId};`;
    console.table(staff);
  } catch (err) {
    console.error("Database query failed:", err.message);
  } finally {
    await sql.end();
  }
}
main();
