async function main() {
  const apiKey = "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";
  console.log("Testing OpenAI API Key...");
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: "Hello, confirm you are working." }],
        temperature: 0.7
      })
    });
    console.log("Status:", response.status);
    const json = await response.json();
    console.log("Response JSON:", JSON.stringify(json, null, 2));
  } catch (err) {
    console.error("OpenAI test failed:", err);
  }
}
main();
