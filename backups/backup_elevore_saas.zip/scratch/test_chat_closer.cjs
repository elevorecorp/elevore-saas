const puppeteer = require('puppeteer');

async function main() {
  console.log('Launching browser via Puppeteer...');
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1000 });

    page.on('console', (msg) => {
      console.log(`[BROWSER CONSOLE] [${msg.type()}]: ${msg.text()}`);
    });

    page.on('pageerror', (err) => {
      console.error(`[BROWSER RUNTIME EXCEPTION]:`, err.message, err.stack);
    });

    const proposalUrl = 'https://elevore-saas.vercel.app/?propuesta=b447ce59-4305-4c73-89dd-37d58bbcd9e6';
    console.log(`Navigating to ${proposalUrl} ...`);
    await page.goto(proposalUrl, { waitUntil: 'networkidle0', timeout: 35000 });

    // Wait for the proposal card to load
    console.log('Waiting for page elements to render...');
    await page.waitForSelector('h2', { timeout: 15000 });

    // Screenshot 1: Loaded proposal page
    await page.screenshot({ path: 'scratch/proposal_loaded.png' });
    console.log('Saved proposal_loaded.png.');

    // Look for chat input field and type message
    console.log('Finding chat input field...');
    const inputSelector = 'input[placeholder*="Pregunta"], input[placeholder*="Escribe"], input[placeholder*="message"]';
    await page.waitForSelector(inputSelector, { timeout: 10000 });
    await page.type(inputSelector, 'hola');

    // Click the send button (the button inside the form)
    console.log('Sending message...');
    await page.keyboard.press('Enter');

    // Wait for AI response
    console.log('Waiting for response (10 seconds)...');
    await new Promise(r => setTimeout(r, 10000));

    // Screenshot 2: After typing and getting a response
    await page.screenshot({ path: 'scratch/proposal_chat_sent.png' });
    console.log('Saved proposal_chat_sent.png.');

  } catch (error) {
    console.error('Error during chat closer test:', error);
  } finally {
    if (browser) {
      await browser.close();
    }
    process.exit(0);
  }
}

main();
