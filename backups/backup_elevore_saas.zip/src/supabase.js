import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const sb = createClient(supabaseUrl, supabaseAnonKey);
if (typeof window !== 'undefined') {
  window.sb = sb;
}
